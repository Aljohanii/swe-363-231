import * as THREE from "three";
// Set a variable to store the last time the user did something.
let lastActivityTime = Date.now();

// Set a function to check for user activity.
function checkUserActivity() {
  // Check if the current time is different from the last time the user did something.

  // Take appropriate action, such as displaying a message to the user or taking some other action.
  const span = document.querySelector("span");
  span.textContent = Number(span.textContent) - 1;
  if (span.textContent == 0) {
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(
      75,
      window.innerWidth / window.innerHeight,
      0.1,
      1000
    );

    const renderer = new THREE.WebGLRenderer();
    renderer.setSize(window.innerWidth, window.innerHeight);
    document.body.appendChild(renderer.domElement);

    const geometry = new THREE.BoxGeometry(1, 1, 1);
    const material = new THREE.MeshBasicMaterial({ color: 0xff_ff_00 });
    const cube = new THREE.Mesh(geometry, material);
    scene.add(cube);

    camera.position.z = 5;

    function animate() {
      requestAnimationFrame(animate);

      cube.rotation.x += 0.01;
      cube.rotation.y += 0.01;

      renderer.render(scene, camera);
    }

    animate();
  }

  // Update the last time the user did something.
  lastActivityTime = document.addEventListener("mousemove", () => {
    span.textContent = 10;
    location.reload();
  });
}

// Set an interval to check for user activity every one second.
const interval = setInterval(checkUserActivity, 1000);
